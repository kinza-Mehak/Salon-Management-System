package com.business.beautybar;



public class CurrentShopSession
{
    private CurrentShopSession()
    {

    }
    public static String shop_name="";
    public static String address="";
    public static String total_years="";
    public static String total_employees="";
    public static String shop_phone="";
    public static String password="";
}
