package com.business.beautybar;



public class CurrentUserSession
{
    private CurrentUserSession()
    {

    }
    public static String name="";
    public static String phone="";
    public static String age="";
    public static String gender="";
    public static String password="";

}
