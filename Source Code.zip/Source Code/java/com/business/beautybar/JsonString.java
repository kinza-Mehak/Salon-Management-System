package com.business.beautybar;



public class JsonString
{
    public static String fetch_all_user_packages="";
    public static String fetch_current_shop_packages="";
}
